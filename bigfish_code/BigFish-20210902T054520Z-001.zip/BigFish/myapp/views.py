from django.shortcuts import render,redirect
from django.http import HttpResponse,JsonResponse
from myapp.models import Admin_db
from myapp.models import Product_db
from myapp.models import Category_db
from myapp.models import Recipe_db
from fishapp.models import Contact_db

from django.core.files.storage import FileSystemStorage
from django.utils.datastructures import MultiValueDictKeyError
def bigfish(request):
    if 'email' in request.session:
        return render(request,'bigfish.html')
    else:
        return redirect(login)
def adminreg(request):
    return render(request,'adminreg.html') 
def admindata(request):
    data=dict()
    if request.method=="POST":
        name_r=request.POST.get('name')
        address_r=request.POST.get('address')
        email_r=request.POST.get('email')
        password_r=request.POST.get('password')
        image_r=request.FILES['image']
        if Admin_db.objects.filter(password=password_r).exists():
            data['message']="invalid password"
            data['error']=0
            return JsonResponse(data)
        if Admin_db.objects.filter(email=email_r).exists():
            data['message']="email id already exists"
            data['error']=0
            return JsonResponse(data)
        adm=Admin_db(name=name_r,address=address_r,email=email_r,password=password_r,image=image_r)
        adm.save()
        data['message']="successfully registered"
        data['error']=1
        return JsonResponse(data)

def productdata(request):
    data=dict()
    if request.method=="POST":
        name_r=request.POST.get('name')
        price_r=request.POST.get('price')
        kg_r=request.POST.get('kg')
        image_r=request.FILES['image']
        category_r=request.POST.get('category')
        if Product_db.objects.filter(name=name_r).exists():
            data['message']="name already exist"
            data['error']=0
            return JsonResponse(data)
        pdt=Product_db(name=name_r,price=price_r,kg=kg_r,image=image_r,category=category_r)
        pdt.save()
        data['message']="successfully registered"
        data['error']=1
        return JsonResponse(data)
        

def productreg(request):
    catadata=Category_db.objects.all()
    print(catadata)
    return render(request,'productreg.html',{'catadata':catadata})
def productview(request):
    data=Product_db.objects.all()
    return render(request,'productview.html',{'data':data})
def adminview(request):
    data=Admin_db.objects.all()
    return render(request,'adminview.html',{'data':data})
def editproduct(request,dataid):    
    data=Product_db.objects.filter(id=dataid)
    dat=Category_db.objects.all()
    return render(request,'editproduct.html',{'data':data,'catadata':dat})
def editadmin(request,dataid):
    data=Admin_db.objects.filter(id=dataid)
    return render(request,'editadmin.html',{'data':data})
def deleteadmin(request,dataid):
    data=Admin_db.objects.filter(id=dataid).delete()
    return redirect("adminview")
def updateadmin(request,dataid):
    if request.method=="POST":
        name_r=request.POST.get('name')
        address_r=request.POST.get('address')
        email_r=request.POST.get('email')
        password_r=request.POST.get('password')

        try:
            image_r=request.FILES['image']
            fs=FileSystemStorage()
            file=fs.save(image_r.name,image_r)
        except MultiValueDictKeyError:
            file=Admin_db.objects.get(id=dataid).image
        Admin_db.objects.filter(id=dataid).update(name=name_r,address=address_r,email=email_r,password=password_r,image=file)
        return redirect("adminview")
def updateproduct(request,dataid):
      if request.method=="POST":
        name_r=request.POST.get('name')
        price_r=request.POST.get('price')
        kg_r=request.POST.get('kg')
        category_r=request.POST.get('category')
        try:
            image_r=request.FILES['image']
            fs=FileSystemStorage()
            file=fs.save(image_r.name,image_r)
        except MultiValueDictKeyError:
            file=Product_db.objects.get(id=dataid).image
        Product_db.objects.filter(id=dataid).update(name=name_r,price=price_r,kg=kg_r,image=file,category=category_r)
        return redirect("productview")
def deleteproduct(request,dataid):
      data=Product_db.objects.filter(id=dataid).delete()
      return redirect(productview)
def categoryreg(request):
    return render(request,'categoryreg.html') 
def categorydata(request):
    data=dict()
    if request.method=="POST":
        name_r=request.POST.get('name')
        image_r=request.FILES['image']
        if Category_db.objects.filter(name=name_r).exists():
            data['message']="name already exist"
            data['error']=0
            return JsonResponse(data)
        ctg=Category_db(name=name_r,image=image_r)
        ctg.save()
        data['message']="successfully registered"
        data['error']=1
        return JsonResponse(data)
def categoryview(request):
    data=Category_db.objects.all()
    return render(request,'categoryview.html',{'data':data})
def editcategory(request,dataid):
    data=Category_db.objects.filter(id=dataid)
    return render(request,'editcategory.html',{'data':data})
def deletecategory(request,dataid):
    data=Category_db.objects.filter(id=dataid).delete()
    return redirect("categoryview")
def updatecategory(request,dataid):
    if request.method=="POST":
        name_r=request.POST.get('name')
        try:
            image_r=request.FILES['image']
            fs=FileSystemStorage()
            file=fs.save(image_r.name,image_r)
        except MultiValueDictKeyError:
            file=Category_db.objects.get(id=dataid).image
        Category_db.objects.filter(id=dataid).update(name=name_r,image=file)
        return redirect("categoryview")
def recipedata(request):
    data=dict()
    if request.method=="POST":
        name_r=request.POST.get('name')
        ingredients_r=request.POST.get('ingredients')
        instruction_r=request.POST.get('instruction')
        time_r=request.POST.get('time')
        image_r=request.FILES['image']
        res=Recipe_db(name=name_r,ingredients=ingredients_r,instruction=instruction_r,time=time_r,image=image_r)
        res.save()
        return HttpResponse ('done!')
def recipee(request):
    return render(request,'recipee.html') 
def recipeeview(request):
    resp=Recipe_db.objects.all()
    return render(request,'recipeeview.html',{'resp':resp})
def contactview(request):
    con=Contact_db.objects.all()
    return render(request,'contactview.html',{'con':con})
def login(request):
    return render(request,'login.html')
def logout(request):
    del request.session['email']
    del request.session['password']
    return redirect(login)
def logindata(request):
    data=dict()
    if request.method=="POST":
        email_r=request.POST.get('email')
        password_r=request.POST.get('password')
        # adm=Admin_db(name=name_r,email=email_r)
        # adm.save()
        # if Admin_db.objects.filter(password=password_r).exists():
        #     data['message']="invalid password"
        #     data['error']=0
        #     return JsonResponse(data)
        if Admin_db.objects.filter(email=email_r,password=password_r).exists():
            request.session['email']=email_r
            request.session['password']=password_r
            d=Admin_db.objects.filter(email=request.session.get('email')).values('image').first()
            print(d)
            # print(d['image'])
            request.session['img']=d['image']
            return redirect("bigfish")
        else:
            return render (request,'login.html',{'message' : 'invalid email or password'})
           

        #     data['message']="email id already exists"
        #     data['error']=0
        #     return JsonResponse(data)
        # data['message']="successfully registered"
        # data['error']=1
        # return JsonResponse(data)






