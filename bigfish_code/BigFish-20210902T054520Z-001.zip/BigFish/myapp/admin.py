from django.contrib import admin
from myapp.models import Admin_db
from myapp.models import Product_db
from myapp.models import Category_db
from myapp.models import Recipe_db


# Register your models here.
admin.site.register(Admin_db)
admin.site.register(Product_db)
admin.site.register(Category_db)
admin.site.register(Recipe_db)
