from django.urls import path, include
from.import views
urlpatterns=[
    path('bigfish/',views.bigfish,name='bigfish'),
    path('adminreg/',views.adminreg,name='adminreg'),
    path('adminview/',views.adminview,name='adminview'),
    path('admindata/',views.admindata,name='admindata'),
    path('editadmin/<int:dataid>',views.editadmin,name="editadmin"),
    path('updateadmin/<int:dataid>',views.updateadmin,name="updateadmin"),
    path('deleteadmin/<int:dataid>',views.deleteadmin,name="deleteadmin"),
    path('productdata/',views.productdata,name="productdata"),
    path('productreg/',views.productreg,name='productreg'),
    path('editproduct/<int:dataid>',views.editproduct,name="editproduct"),
    path('updateproduct/<int:dataid>',views.updateproduct,name="updateproduct"),
    path('deleteproduct/<int:dataid>',views.deleteproduct,name="deleteproduct"),
    path('productview/',views.productview,name='productview'),
    path('categoryreg/',views.categoryreg,name='categoryreg'),
    path('categoryview/',views.categoryview,name='categoryview'),
    path('categorydata/',views.categorydata,name='categorydata'),
    path('editcategory/<int:dataid>',views.editcategory,name="editcategory"),
    path('updatecategory/<int:dataid>',views.updatecategory,name="updatecategory"),
    path('deletecategory/<int:dataid>',views.deletecategory,name="deletecategory"),
    path('recipedata/',views.recipedata,name='recipedata'),
    path('recipeeview/',views.recipeeview,name='recipeeview'),
    path('recipee/',views.recipee,name='recipee'),
    path('contactview/',views.contactview,name='contactview'),
    path('login/',views.login,name='login'),
    path('logindata/',views.logindata,name='logindata'),
    path('logout/',views.logout,name='logout'),
    

   


]