from django.db import models
class Admin_db(models.Model):
    name=models.CharField(max_length=20,null=True,blank=True)
    address=models.CharField(max_length=30,null=True,blank=True)
    email=models.CharField(max_length=20,null=True,blank=True)
    password=models.CharField(max_length=20,null=True,blank=True)
    image=models.ImageField(upload_to='adminimage/',null=True,blank=True)
    
class Product_db(models.Model):
    name=models.CharField(max_length=20,null=True,blank=True)
    price=models.CharField(max_length=20,null=True,blank=True)
    image=models.ImageField(upload_to='productimage/',null=True,blank=True)
    kg=models.CharField(max_length=20,null=True,blank=True)
    category=models.CharField(max_length=20,null=True,blank=True)
class Category_db(models.Model):
   name=models.CharField(max_length=20,null=True,blank=True)
   image=models.ImageField(upload_to='categoryimage/',null=True,blank=True)
class Recipe_db(models.Model):
    name=models.CharField(max_length=20,null=True,blank=True)
    ingredients=models.CharField(max_length=20,null=True,blank=True)
    instruction=models.CharField(max_length=20,null=True,blank=True)
    time=models.CharField(max_length=20,null=True,blank=True)
    image=models.ImageField(upload_to='recipeeimage/',null=True,blank=True)




    


