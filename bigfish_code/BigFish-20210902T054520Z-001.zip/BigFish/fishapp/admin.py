from django.contrib import admin
from fishapp.models import Contact_db
from fishapp.models import Website_db
from fishapp.models import Cart_db

# Register your models here.
admin.site.register(Contact_db)
admin.site.register(Website_db)
admin.site.register(Cart_db)