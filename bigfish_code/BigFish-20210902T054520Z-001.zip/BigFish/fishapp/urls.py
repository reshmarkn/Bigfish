from django.urls import path, include
from fishapp import views
urlpatterns=[
     path('',views.index,name='index'),
     path('shop/',views.shop,name='shop'),
     path('shopfilter/<str:cat>/',views.shopfilter,name='shopfilter'),
     path('details/<int:prodid>/',views.details,name='details'),
     path('contact/',views.contact,name='contact'),
     path('about/',views.about,name='about'),
     path('recipeee/',views.recipeee,name='recipeee'),
     path('res/<int:resid>/',views.res,name='res'),
     path('contactdata/',views.contactdata,name='contactdata'),
     path('loggin/',views.loggin,name='loggin'),
     path('websitereg/',views.websitereg,name='websitereg'),
     path('websitedata/',views.websitedata,name='websitedata'),
     path('loggout/',views.loggout,name='loggout'),
     path('loggindata/',views.loggindata,name='loggindata'),
     path('cartdata/',views.cartdata,name='cartdata')
]
