from django.db import models

class Contact_db(models.Model):
    name=models.CharField(max_length=20,null=True,blank=True)
    email=models.CharField(max_length=20,null=True,blank=True)
    message=models.CharField(max_length=20,null=True,blank=True)
class Website_db(models.Model):
    firstname=models.CharField(max_length=20,null=True,blank=True)
    lastname=models.CharField(max_length=20,null=True,blank=True)
    email=models.CharField(max_length=20,null=True,blank=True)
    password=models.CharField(max_length=20,null=True,blank=True)
    phoneno=models.CharField(max_length=20,null=True,blank=True)
class Cart_db(models.Model):
    cartid=models.CharField(max_length=20,null=True,blank=True)
    productid=models.CharField(max_length=20,null=True,blank=True)
    quantity=models.CharField(max_length=20,null=True,blank=True)
    totalprice=models.CharField(max_length=20,null=True,blank=True)


