from django.apps import AppConfig


class FishappConfig(AppConfig):
    name = 'fishapp'
