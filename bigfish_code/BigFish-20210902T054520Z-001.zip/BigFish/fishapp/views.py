from django.shortcuts import render,redirect
from django.http import HttpResponse
from myapp.models import Category_db
from myapp.models import Product_db
from fishapp.models import Contact_db
from fishapp.models import Website_db
from fishapp.models import Cart_db
from myapp.models import Recipe_db
def index(request):
    catedata=Category_db.objects.all()
    print(catedata)
    prodata=Product_db.objects.all()
    print(prodata)
    return render(request,'index.html',{'catedata':catedata,'prodata':prodata})
def shop(request):
    catdata=Category_db.objects.all()
    print(catdata)
    prodata=Product_db.objects.all()
    print(prodata)
    return render(request,'shop.html',{'catdata':catdata,'prodata':prodata})
def shopfilter(request,cat):
    print(cat)
    catdata=Category_db.objects.all()
    print(catdata)
    prodata=Product_db.objects.filter(category=cat)
    print(prodata)
    return render(request,'shop.html',{'catdata':catdata,'prodata':prodata})
def details(request,prodid):
    print(prodid)
    prodata=Product_db.objects.filter(id=prodid)
    return render(request,'details.html',{'prodata':prodata})
def contact(request):
    return render(request,'contact.html')
def about(request):
    return render(request,'about.html')

def contactdata(request):
    data=dict()
    if request.method=="POST":
        name_r=request.POST.get('name')
        email_r=request.POST.get('email')
        message_r=request.POST.get('message')
        con=Contact_db(name=name_r,email=email_r,message=message_r)
        con.save()
        return HttpResponse('done!')
def loggin(request):
    return render(request,'loggin.html')
def websitereg(request):
    return render(request,'websitereg.html')
# def loggindata(request):
#     data=dict()
#     if request.method=="POST":
#         email_r=request.POST.get('email')
#         password_r=request.POST.get('password')
def websitedata(request):
    data=dict()
    if request.method=="POST":
        firstname_r=request.POST.get('firstname')
        lastname_r=request.POST.get('lastname')
        email_r=request.POST.get('email')
        password_r=request.POST.get('password')
        phoneno_r=request.POST.get('phoneno')
        web=Website_db(firstname=firstname_r,lastname=lastname_r,email=email_r,password=password_r,phoneno=phoneno_r)
        web.save()
        return HttpResponse('done!')
def loggindata(request):
    data=dict()
    if request.method=="POST":
        
        email_r=request.POST.get('email')
        password_r=request.POST.get('password')
       
        if Website_db.objects.filter(email=email_r,password=password_r).exists():
            request.session['email']=email_r
            request.session['password']=password_r
            # d=Website_db.objects.filter(email=request.session.get('email')).first()
            # print(d)
            return redirect(index)
        else:
            return render(request,'loggin.html',{'message' :'invalid email or password'})
def loggout(request):
    del request.session['email']
    del request.session['password']
    return redirect(index)
def cartdata(request):
    data=dict()
    if request.method=="POST":
        cartid_r=request.POST.get('prodid')
        productid_r=request.POST.get('prodid')
        quantity_r=request.POST.get('kg')
        totalprice_r=request.POST.get('tot ')
        car=Cart_db(cartid=cartid_r,productid=productid_r,quantity=quantity_r,totalprice=totalprice_r)
        car.save()
        return redirect('index')
def recipeee(request):
    resdata=Recipe_db.objects.all()
    print(resdata)
    return render(request,'recipeee.html',{'resdata':resdata})
def res(request,resid):
    print(resid)
    resdata=Recipe_db.objects.filter(id=resid)
    return render(request,'res.html',{'resdata':resdata})
